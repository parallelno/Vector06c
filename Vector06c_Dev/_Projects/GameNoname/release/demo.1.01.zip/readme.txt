extract the zip file.
run _run.bat file
enjoy