ar002 -- written by Haruhiko Okumura and released to the public domain
